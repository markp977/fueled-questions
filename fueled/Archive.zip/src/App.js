import EditableHeader from './components/EditableHeader/default';
import './App.css';

function App() {
  return (
    <div className="Main">
      <EditableHeader initialText="SampleText" />
      {/* <AddQuestion/>
      <Save/> */}
    </div>
  );
}

export default App;
